from pathlib import Path
import logging
import subprocess


def compress_video(
    input_file: Path,
    output_file: Path,
) -> Path:

    logging.info(
        "Compressing video..."
    )

    command = [
        "ffmpeg",
        "-y",
        "-i",
        str(input_file),
        "-c:v",
        "libx264",
        "-preset",
        "veryfast",
        "-crf",
        "28",
        "-c:a",
        "aac",
        "-b:a",
        "96k",
        str(output_file),
    ]

    subprocess.run(
        command,
        check=True,
    )

    logging.info(
        "Compressed video created: %s",
        output_file,
    )

    return output_file