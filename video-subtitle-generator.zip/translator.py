#!/usr/bin/env python3

from pathlib import Path
import argparse
import logging
import sys

import torch
import whisper

from compressor import compress_video
from translator import ArgosTranslator


def setup_logging(verbose=False):

    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )


def get_device():

    if torch.cuda.is_available():

        vram = (
            torch.cuda.get_device_properties(0)
            .total_memory
            / (1024 ** 3)
        )

        return "cuda", vram

    return "cpu", 0


def select_model(vram):

    if vram >= 10:
        return "large"

    if vram >= 6:
        return "medium"

    if vram >= 4:
        return "small"

    return "base"


def format_timestamp(seconds):

    millis = int(seconds * 1000)

    hours = millis // 3600000
    millis %= 3600000

    minutes = millis // 60000
    millis %= 60000

    secs = millis // 1000
    millis %= 1000

    return (
        f"{hours:02}:"
        f"{minutes:02}:"
        f"{secs:02},"
        f"{millis:03}"
    )


def save_srt(result, output_file):

    with open(
        output_file,
        "w",
        encoding="utf-8",
    ) as f:

        for idx, segment in enumerate(
            result["segments"],
            start=1,
        ):

            f.write(f"{idx}\n")

            f.write(
                f"{format_timestamp(segment['start'])}"
                f" --> "
                f"{format_timestamp(segment['end'])}\n"
            )

            f.write(
                segment["text"].strip()
            )

            f.write("\n\n")


def main():

    parser = argparse.ArgumentParser()

    parser.add_argument("file")

    parser.add_argument(
        "--compress",
        action="store_true",
    )

    parser.add_argument(
        "--translate",
        action="store_true",
    )

    parser.add_argument(
        "--language",
        default="en",
    )

    parser.add_argument(
        "--target-lang",
        default="pt",
    )

    parser.add_argument(
        "--output",
        default="output",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
    )

    args = parser.parse_args()

    setup_logging(
        args.verbose
    )

    input_file = Path(
        args.file
    )

    output_dir = Path(
        args.output
    )

    output_dir.mkdir(
        parents=True,
        exist_ok=True,
    )

    working_file = input_file

    if args.compress:

        compressed_file = (
            output_dir /
            f"{input_file.stem}.compressed.mp4"
        )

        working_file = compress_video(
            input_file,
            compressed_file,
        )

    device, vram = get_device()

    model_name = select_model(
        vram
    )

    logging.info(
        "Device: %s",
        device,
    )

    logging.info(
        "Model: %s",
        model_name,
    )

    try:

        model = whisper.load_model(
            model_name,
            device=device,
        )

    except RuntimeError:

        device = "cpu"

        model = whisper.load_model(
            model_name,
            device="cpu",
        )

    result = model.transcribe(
        str(working_file),
        language=args.language,
        fp16=(device == "cuda"),
        verbose=False,
    )

    srt_file = (
        output_dir /
        f"{input_file.stem}.srt"
    )

    txt_file = (
        output_dir /
        f"{input_file.stem}.txt"
    )

    save_srt(
        result,
        srt_file,
    )

    txt_file.write_text(
        result["text"],
        encoding="utf-8",
    )

    if args.translate:

        translator = ArgosTranslator(
            source_lang=args.language,
            target_lang=args.target_lang,
        )

        translated = (
            translator.translate_segments(
                result
            )
        )

        translated_srt = (
            output_dir /
            f"{input_file.stem}.{args.target_lang}.srt"
        )

        translated_txt = (
            output_dir /
            f"{input_file.stem}.{args.target_lang}.txt"
        )

        save_srt(
            translated,
            translated_srt,
        )

        translated_txt.write_text(
            translated["text"],
            encoding="utf-8",
        )

    logging.info(
        "Finished successfully"
    )


if __name__ == "__main__":
    try:
        main()

    except KeyboardInterrupt:
        sys.exit(130)

    except Exception:
        logging.exception(
            "Unexpected error"
        )
        sys.exit(1)